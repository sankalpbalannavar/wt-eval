const express = require('express');

const app = express();

const mysql = require('mysql')
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "kle",
    port: "3308"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.set("view engine", "ejs")

app.get('/', (req, res) => {
    res.render("index");
})

app.post('/', (req, res) => {
    var username = req.body.username
    var password = req.body.password
    console.log(username)
    console.log(password)

    const result = check({
        username: username,
        password: password
    })

    console.log(result)
})

app.get('/insert', (req, res) => {
    var sql="select * from test"

    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log(result);
        res.render("insert",{username:result});
      });
    
})

app.post('/insert', (req, res) => {
    var un = req.body.username

    var sql = "insert into test values(?)"
    con.query(sql,[un], function (err, result) {
        if (err) throw err;
        console.log(result);
      });
})

app.listen(4000, () => {
    console.log("App listening on port 4000.");
})